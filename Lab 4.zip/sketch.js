let angle = 0;
let radius = 400;
let spin = 1;

function setup() {
  createCanvas(1000, 1000);
  stroke(255);
  
}

function draw() {
  background(50);
  
  stroke(255);
  strokeWeight(5);
  noFill();
  ellipse(width / 2,height /2, 800,800)
  
  let x = width / 2 + cos(angle)* radius;
  let y = height / 2 + sin(angle) * radius;
  
  line(width /2, height / 2 , x, y);
  
  angle += spin / 100;
  
  noStroke();
  fill(255);
  textSize(24);
  text('Speed: ' + spin,width /2 -50,height -20);
  
  rect(25,height-75, 50, 50, 10)
  
  rect(width -75,height-75, 50, 50, 10)
  
  fill(50);
  
  rect(35, height -55, 30,10);
  
  rect(width -65, height -55, 30,10);
  rect(width - 55, height -65, 10,30);
}

function mousePressed() {
  
  // check if in Plus Box
  if (mouseX < width - 25 && mouseX > width - 75){
    if (mouseY < height - 25 && mouseY > height - 75){
      spin += 1;
    }
  }
  
  // check if in Minus Box
  if (mouseX < 75 && mouseX > 25){
    if (mouseY < height - 25 && mouseY > height - 75){
      spin -= 1;
    }
  }
  
}

function keyPressed() {
  
  if (keyCode === UP_ARROW) {
    spin += 1;
  } else if (keyCode === DOWN_ARROW) {
    spin -= 1;
  }
  
}