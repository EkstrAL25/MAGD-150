let aliens = [
  [1,0,1,1,1,1,1,0,1,1,1,1],
  [1,1,1,0,1,1,1,1,1,0,1,1],
  [0,1,1,1,0,1,0,1,1,1,1,1],
  [1,1,0,1,1,1,1,1,0,1,1,0],
];

let shipX = 0;

let startX = 30;
let startY = 10;
let countUp = true;

function setup() {

  createCanvas(800,450);
  
  

	

}

function draw() {
  
  background(5);
  
  if(countUp && startY >=90 ){
    countUp = false;
  }
  if (!countUp && startY <10){
    countUp = true;
  }
  
  if (countUp){
    startY++;
  } else {
    startY--;
  }
  
 
  
  for (var x = 0; x < 4; x++){
    for (var y = 0; y < 12; y++){
      if (aliens[x][y] == 1){
        drawAlien(x * 40 + startX, y * 60 + startY,4,'red');
      }
    }
  }
  
  if (mouseX < 10)
    {
      drawShip(400,10,4,'blue')
    }
  else if (mouseX > 720) {
    drawShip(400,720,4,'blue')
  } else {
    drawShip(400, mouseX,4,'blue');
  }

	
}

function drawAlien(X ,Y , pixelSize, color){
  
  let drawArray =
      
    [[0,0,1,0,0,0,0,0,1,0,0],
    [0,0,0,1,0,0,0,1,0,0,0],
    [0,0,1,1,1,1,1,1,1,0,0],
    [0,1,1,0,1,1,1,0,1,1,0],
    [1,1,1,1,1,1,1,1,1,1,1],
    [1,0,1,1,1,1,1,1,1,0,1],
    [1,0,1,0,0,0,0,0,1,0,1],
    [0,0,0,1,1,0,1,1,0,0,0]];
  
  noStroke();
  noFill();
  
  for (var x = 0; x < 8; x++){
    for (var y = 0; y < 11; y++){
      if (drawArray[x][y] == 1){
        fill(color);
      }
      rect(Y + (y * pixelSize),X + (x * pixelSize),  pixelSize);
      noFill();
    }
  }
}

function drawShip(X ,Y , pixelSize, color){
  
  let drawArray =
      
    [[0,0,0,0,0,0,1,0,0,0,0,0,0],
     [0,0,0,0,0,1,1,1,0,0,0,0,0],
     [0,1,1,1,1,1,1,1,1,1,1,1,0],
     [1,1,1,1,1,1,1,1,1,1,1,1,1],
     [1,1,1,1,1,1,1,1,1,1,1,1,1],
     [1,1,1,1,1,1,1,1,1,1,1,1,1]
    ];
  
  noStroke();
  noFill();
  
  for (var x = 0; x < 6; x++){
    for (var y = 0; y < 13; y++){
      if (drawArray[x][y] == 1){
        fill(color);
      }
      rect(Y + (y * pixelSize),X + (x * pixelSize),  pixelSize);
      noFill();
    }
  }
}