let backgroundColor = 'gray'

function setup() {

  createCanvas(1000, 1000);

}

function draw() {

  background('#B3EDFF'); // Set background color

  // Draw monitor

  fill(25);

  rect(100, 100, 800, 800);
  
  fill(backgroundColor);
  
  rect(110,110,780,580);

  // Draw keyboard

  fill('#6ECEEB');

  rect(200, 750, 175, 100);

  // Draw keyboard keys
  fill('#EB7A9B');
  rect(225,775,50,50);
  
  
  fill('#63EBC0');
  ellipse(325,800,50,50);
  
  fill('#EB9B4B');
  ellipse(800,800,100,100);
  

}

function mousePressed() {
  var d = dist(mouseX, mouseY, 325, 800);
  if (mouseX >= 225 && mouseX <= 275) {
    if(mouseY >=775 && mouseY <= 825){
      backgroundColor = '#EB7A9B';
    }
  }
  else if (d <= 25){
    backgroundColor = '#63EBC0';
  }
  else if (keyIsPressed) {
		
		if (key == 'x') {
          var j = dist(mouseX, mouseY, 800, 800);	
			if (j < 100) {
			  backgroundColor = '#EB9B4B';
			} 
		}
	}

  
}